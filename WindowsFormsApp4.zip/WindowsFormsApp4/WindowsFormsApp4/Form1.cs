﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
    //Had multiple attempts at this without a console printout. Had to fix a CS0017 error for multiple Main statements, apparently just rename one
{
    public partial class Form1 : Form
    {
        public static void Main1(string[] args)
        {
            int[] arr = new int[] {
            7,
            4,
            6,
            2
         };
            // given integer
            int res = 8;
            Console.WriteLine("Given Integer {0}: ", res);
            Console.WriteLine("Sum of:");
            for (int i = 0; i < arr.Length; i++)
            {
                for (int j = 0; j < arr.Length; j++)
                {
                    if (i != j)
                    {
                        int sum = arr[i] + arr[j];
                        if (sum == res)
                        {
                            Console.WriteLine(arr[i]);
                        }
                    }
                }
            }
        }
    }
}